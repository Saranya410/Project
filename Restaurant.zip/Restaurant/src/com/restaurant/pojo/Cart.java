package com.restaurant.pojo;

public class Cart {
	int customerId;
	int foodId;
	int quantity;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getFoodId() {
		return foodId;
	}

	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Cart [customerId=" + customerId + ", foodId=" + foodId + ", quantity=" + quantity + "]";
	}

}
