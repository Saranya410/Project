package com.restaurant.pojo;

public class Food {
	int foodId;
	int restaurantId;
	String foodName;
	int price;
	int quantity;

	public int getFoodId() {
		return foodId;
	}

	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}

	public int getRestaurantId() {
		return restaurantId;
	}

	public void setRestaurantId(int restaurantId) {
		this.restaurantId = restaurantId;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Food [foodId=" + foodId + ", restaurantId=" + restaurantId + ", foodname=" + foodName + ", price="
				+ price + ", quantity=" + quantity + "]";
	}

}
