package com.restaurant.pojo;

public class Login {
	
	private int lid;
	private String username;
	private String password;
	private String accountType;
	
	public int getLid() {
		return lid;
	}
	public void setLid(int lid) {
		this.lid = lid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	@Override
	public String toString() {
		return "Login [lid=" + lid + ", username=" + username + ", password=" + password + ", accountType="
				+ accountType + "]";
	}
	
}
