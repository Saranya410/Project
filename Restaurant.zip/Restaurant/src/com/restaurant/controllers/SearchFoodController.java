

package com.restaurant.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.restaurant.dao.FoodDAO;
import com.restaurant.pojo.Food;

import org.springframework.ui.ModelMap;

@Controller
@RequestMapping("search")
public class SearchFoodController {

	@RequestMapping( method = RequestMethod.GET)
	public String printHello(ModelMap model, HttpServletRequest request) {
		
		String input = request.getParameter("input");
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		FoodDAO foodDao = (FoodDAO) context.getBean("foodDAO");
		
		List<Food> foods = foodDao.getFood(input);
		request.setAttribute("foods", foods);
		
		return "searchresults";
		
		

	}
}
