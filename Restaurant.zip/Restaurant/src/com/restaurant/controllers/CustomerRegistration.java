
package com.restaurant.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.restaurant.dao.CustomerDAO;
import com.restaurant.dao.LoginDAO;
import com.restaurant.pojo.Customer;
import com.restaurant.pojo.Login;

import org.springframework.ui.ModelMap;

@Controller
@RequestMapping("/custregistrationcontroller")
public class CustomerRegistration {

	@RequestMapping(method = RequestMethod.POST)
	public String printHello(ModelMap model, HttpServletRequest request) {

		String username = request.getParameter("Username");
		String password = request.getParameter("Password");
		String fullName = request.getParameter("FullName");
		double number = Double.parseDouble(request.getParameter("number"));
		String eMail = request.getParameter("Email");
		String addressLine1 = request.getParameter("AddressLine1");
		String city = request.getParameter("City");
		String addressLine2 = request.getParameter("AddressLine2");
		String state = request.getParameter("State");
		int pincode = Integer.parseInt(request.getParameter("Pincode"));
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		LoginDAO lDao = (LoginDAO) context.getBean("loginDAO");
		CustomerDAO cDao = (CustomerDAO) context.getBean("customersDAO");
		
		Login l = new Login();
		l.setPassword(password);
		l.setUsername(username);
		l.setAccountType("customer");
		
		int lid = lDao.insertRow(l);
		
		Customer c = new Customer();
		c.setCustomerId(lid);
		c.setCustomerName(fullName);
		c.setAddressLine1(addressLine1);
		c.setAddressLine2(addressLine2);
		c.setCity(city);
		c.setMobNo(number);
		c.setPinCode(pincode);
		c.setEmailID(eMail);
		c.setState(state);
		
		cDao.insertRow(c);
		return "index";

		
	}
	
	
	
	@RequestMapping(method = RequestMethod.GET)
	public String printHelloGet(ModelMap model, HttpServletRequest request) {

		return printHello(model, request);
		
	}
}
