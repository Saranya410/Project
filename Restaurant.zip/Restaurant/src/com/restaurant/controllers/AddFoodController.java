package com.restaurant.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.catalina.Session;
import org.apache.catalina.connector.Request;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.restaurant.dao.FoodDAO;
import com.restaurant.pojo.Food;

import org.springframework.ui.ModelMap;

@Controller
@RequestMapping("restaurant/addfoodcontroller")
public class AddFoodController {

	@RequestMapping(method = RequestMethod.GET)
	public String printHello(ModelMap model, HttpServletRequest request) {
		
		String foodName = request.getParameter("FoodName");
		int quantity = Integer.parseInt(request.getParameter("Quantity"));
		int price = Integer.parseInt(request.getParameter("Price"));
		
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		FoodDAO foodDao = (FoodDAO) context.getBean("foodDao");
		
		int restaurantId = Integer.parseInt((String) request.getSession().getAttribute("username"));
		
		Food food = new Food();
		food.setFoodName(foodName);
		food.setPrice(price);
		food.setQuantity(quantity);
		food.setRestaurantId(restaurantId);
		
		foodDao.insertRow(food);
		return "restaurantaddfood";
		
	}
}



