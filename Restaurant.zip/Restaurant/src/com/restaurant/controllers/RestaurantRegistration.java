package com.restaurant.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.restaurant.dao.CustomerDAO;
import com.restaurant.dao.LoginDAO;
import com.restaurant.dao.RestaurantDAO;
import com.restaurant.pojo.Customer;
import com.restaurant.pojo.Login;
import com.restaurant.pojo.Restaurant;

import org.springframework.ui.ModelMap;

@Controller
@RequestMapping("restregistrationcontroller")
public class RestaurantRegistration {

	@RequestMapping(method = RequestMethod.POST)
	public String printHello(ModelMap model, HttpServletRequest request) {

		String username = request.getParameter("Username");
		String password = request.getParameter("Password");
		String fullName = request.getParameter("FullName");
		double number = Double.parseDouble(request.getParameter("Number"));
		String eMail = request.getParameter("Email");
		String addressLine1 = request.getParameter("AddressLine1");
		String city = request.getParameter("City");
		String addressLine2 = request.getParameter("AddressLine2");
		String state = request.getParameter("State");
		int pincode = Integer.parseInt(request.getParameter("Pincode"));
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		LoginDAO lDao = (LoginDAO) context.getBean("loginDAO");
		
		RestaurantDAO rDao = (RestaurantDAO) context.getBean("restaurantsDAO");
		
		Login l = new Login();
		l.setPassword(password);
		l.setUsername(username);
		l.setAccountType("restaurant");
		
		int lid = lDao.insertRow(l);
		
		Restaurant r = new Restaurant();
		r.setRestaurantId(lid);
		r.setRestaurantName(fullName);
		r.setAddressLine1(addressLine1);
		r.setAddressLine2(addressLine2);
		r.setCity(city);
		r.setMobileNo(number);
		r.setPincode(pincode);
		r.setEmail(eMail);
		r.setState(state);
		
		rDao.insertRow(r);
		return "index";
		
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public String printHelloGET(ModelMap model, HttpServletRequest request) {

		return printHello(model, request);
	}
	
}
