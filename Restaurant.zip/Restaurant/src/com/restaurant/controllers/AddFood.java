package com.restaurant.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import org.springframework.ui.ModelMap;

@Controller
@RequestMapping("restaurant/addfood")
public class AddFood {

	@RequestMapping(method = RequestMethod.GET)
	public String printHello(ModelMap model, HttpServletRequest request) {
		return "restaurantaddfood";
	}
}



