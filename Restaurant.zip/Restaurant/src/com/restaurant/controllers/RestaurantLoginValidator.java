package com.restaurant.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.restaurant.dao.LoginDAO;

import org.springframework.ui.ModelMap;

@Controller
@RequestMapping("online/validaterestaurant")
public class RestaurantLoginValidator {

	@RequestMapping(method = RequestMethod.POST)
	public String printHello(ModelMap model, HttpServletRequest request) {

		String username = request.getParameter("username");
		String password = request.getParameter("password");

		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		LoginDAO lDao = (LoginDAO) context.getBean("loginDAO");
		if (lDao.validateUser(username, password)) {
			return "restrodash";
		} else {
			System.out.println("Failure");
			return "restaurantlogin";
		}
		

	}
}
