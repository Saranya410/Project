package com.restaurant.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.restaurant.pojo.Orders;

public class OrdersDAO {
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public boolean insertRow(Orders ord) {
		String sql = String.format("INSERT INTO ORDERS VALUES(%d,%d,'%s')", ord.getCustomerId(), ord.getRestaurantId(),
				ord.getTime());
		int affectedRows=jdbcTemplate.update(sql);
		if(affectedRows>0)
			return true;
		else
			return false;
	}
public Orders getOrders(int restaurantId){
	String sql="SELECT * FROM ORDERS WHERE RESTAURANT_ID ='"+restaurantId+"'";
	List<Orders> list=jdbcTemplate.query(sql, new RowMapper<Orders>() {

		@Override
		public Orders mapRow(ResultSet rs, int rowId) throws SQLException {
			// TODO Auto-generated method stub
			Orders o=new Orders();
			o.setOrderId(rs.getInt(1));
			o.setCustomerId(rs.getInt(2));
			o.setRestaurantId(rs.getInt(3));
			o.setTime(rs.getString(4));
			return o;
		}});
	return list.get(0);
}
}
