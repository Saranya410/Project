package com.restaurant.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.restaurant.pojo.Food;

public class FoodDAO {
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public boolean insertRow(Food food) {
		String sql = String.format("INSERT INTO FOODS(RESTAURANT_ID, FOOD_NAME, PRICE, QUANTITY) VALUES(%d,'%s',%d,%d)", food.getRestaurantId(),
				food.getFoodName(), food.getPrice(), food.getQuantity());
		int affectedRows = jdbcTemplate.update(sql);
		if (affectedRows > 0) {
			return true;
		} else {
			return false;
		}
	}
	//String sql = "SELECT * FROM FOODS WHERE FOOD_NAME LIKE %'" + input + "'% OR (SELECT RESTAURANT_NAME FROM RESTUARANTS R WHERE R.RESTAURANT_ID = F.RESTAURANT_ID) LIKE %'" + input + "'%";
	public List<Food> getFood(String input) {
		String sql = "SELECT * FROM FOODS WHERE FOOD_NAME LIKE '%" + input + "%'";
		System.out.println(sql);
		List<Food> list = jdbcTemplate.query(sql, new RowMapper<Food>() {

			@Override
			public Food mapRow(ResultSet rs, int rowId) throws SQLException {
				Food food = new Food();
				food.setFoodId(rs.getInt(1));
				food.setRestaurantId(rs.getInt(2));
				food.setFoodName(rs.getString(3));
				food.setPrice(rs.getInt(4));
				food.setQuantity(rs.getInt(5));
				return food;
			}
		});
		return list;
	}
}
