package com.restaurant.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.restaurant.pojo.Cart;

public class CartDAO {
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public Boolean insertRow(Cart cart) {
		String sql = String.format("INSERT INTO CART VALUES(%d,%d,%d)", cart.getCustomerId(), cart.getFoodId(),
				cart.getQuantity());
		int affectedRows = jdbcTemplate.update(sql);
		if (affectedRows > 0)
			return true;
		else
			return false;
	}

	public List getCart(int customerId) {
		String sql = "SELECT * FROM CART WHERE CUSTOMER_ID='" + customerId + "'";

		List<Cart> list = jdbcTemplate.query(sql, new RowMapper<Cart>() {

			@Override
			public Cart mapRow(ResultSet rs, int rowId) throws SQLException {
				// TODO Auto-generated method stub
				Cart cart = new Cart();
				cart.setCustomerId(rs.getInt(1));
				cart.setFoodId(rs.getInt(2));
				cart.setQuantity(rs.getInt(3));

				return cart;
			}
		});
		return list;
	}

}
