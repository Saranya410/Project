package com.restaurant.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.restaurant.pojo.OrderDetails;

public class OrderDetailsDAO {
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public boolean insertRow(OrderDetails ordt) {
		String sql = String.format("INSERT INTO ORDERS_DETAILS VALUES(%d,%d,%d)",
				ordt.getOrderId(), ordt.getFoodId(), ordt.getQuantity());
		int affectedRows=jdbcTemplate.update(sql);
		if(affectedRows>0)
			return true;
		else 
			return false;
		}
	public OrderDetails getOrdersDetails(int orderId)
	{
		String sql="SLECT * FROM ORDER_DETAILS WHERE ORDER_ID='"+orderId+"'";
		List<OrderDetails> list=jdbcTemplate.query(sql,new RowMapper<OrderDetails>() {

			@Override
			public OrderDetails mapRow(ResultSet rs, int rowId) throws SQLException {
				OrderDetails od=new OrderDetails();
				od.setOrderId(rs.getInt(1));
				od.setFoodId(rs.getInt(2));
				od.setQuantity(rs.getInt(3));
				return od;
			}} );
	return list.get(0);
	}
	public OrderDetails getOrdersByRestId(int restaurantId)
	{
		String sql="SLECT * FROM ORDER_DETAILS WHERE RESTAURANT_ID='"+restaurantId+"'";	
		List<OrderDetails> list=jdbcTemplate.query(sql, new RowMapper<OrderDetails>() {

			@Override
			public OrderDetails mapRow(ResultSet rs, int rowId) throws SQLException {
				// TODO Auto-generated method stub
				OrderDetails od1=new OrderDetails();
				od1.setOrderId(rs.getInt(1));
				od1.setFoodId(rs.getInt(2));
				od1.setQuantity(rs.getInt(3));
				
				return od1;
			}});
		return list.get(0);
		
	}
	
}
