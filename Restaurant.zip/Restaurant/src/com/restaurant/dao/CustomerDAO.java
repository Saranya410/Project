package com.restaurant.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.restaurant.pojo.Customer;

public class CustomerDAO {

	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public boolean insertRow(Customer cust) {
		String sql = String.format("insert into customers values(%d, '%s', '%s', '%s', '%s', '%s', '%s', %d, '%s')",
				cust.getCustomerId(), cust.getCustomerName(), cust.getEmailID(), cust.getAddressLine1(), cust.getAddressLine2(), cust.getCity(),
				cust.getState(), cust.getPinCode(), cust.getMobNo());
		int affectedRows = jdbcTemplate.update(sql);
		if (affectedRows > 0)
			return true;
		else
			return false;
	}
	public Customer getCustomer(int custId){
		String sql="SELECT * FROM CUSTOMERS WHERE CUSTOMER_ID='"+custId+"'";
		List<Customer> list = jdbcTemplate.query(sql ,new RowMapper<Customer>() {

			@Override
			public Customer mapRow(ResultSet rs, int rowId) throws SQLException {
				Customer cust = new Customer();
				
				cust.setCustomerId(rs.getInt(1));
				cust.setEmailID(rs.getString(2));
				cust.setAddressLine1(rs.getString(3));
				cust.setAddressLine2(rs.getString(4));
				cust.setCity(rs.getString(5));
				cust.setState(rs.getString(6));
				cust.setPinCode(rs.getInt(7));
				cust.setMobNo(rs.getDouble(8));
				return cust;
			}
			
		});
		return list.get(0);
	}
}
