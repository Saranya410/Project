package com.restaurant.dao;

import com.restaurant.pojo.Restaurant;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class RestaurantDAO {
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public boolean insertRow(Restaurant rest) {
		String sql = String.format("insert into restaurants values(%d, '%s', '%s', '%s', '%s', '%s', '%s', %d, '%s')",
				rest.getRestaurantId(), rest.getRestaurantName(), rest.getEmail(), rest.getAddressLine1(), rest.getAddressLine2(), rest.getCity(), rest.getState(),
				rest.getPincode(), rest.getMobileNo());
		System.out.println(sql);
		int affectedRows = jdbcTemplate.update(sql);
		if (affectedRows > 0)
			return true;
		else
			return false;
		}
	public Restaurant getRestuarant(int restaurentId){
		String sql="SELECT * FROM RESTAURANTS WHERE RESTAURANT_ID='"+restaurentId+"'";
		System.out.println(sql);
		List<Restaurant> list=jdbcTemplate.query(sql,new RowMapper<Restaurant>(){

			@Override
			public Restaurant mapRow(ResultSet rs, int rowId) throws SQLException {
				Restaurant rest=new Restaurant();
				rest.setRestaurantId(rs.getInt(1));
				rest.setRestaurantName(rs.getString(2));
				rest.setEmail(rs.getString(3));
				rest.setAddressLine1(rs.getString(4));
				rest.setAddressLine2(rs.getString(5));
				rest.setCity(rs.getString(6));
				rest.setState(rs.getString(7));
				rest.setPincode(rs.getInt(8));
				rest.setMobileNo(rs.getDouble(9));
				return rest;
			}});
		return list.get(0);
	}
}
