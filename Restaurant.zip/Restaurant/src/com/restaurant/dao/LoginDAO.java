package com.restaurant.dao;
import com.restaurant.pojo.Login;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class LoginDAO {
	
	public LoginDAO() {
	}
	
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public int insertRow(Login l) {
		String sql = String.format("insert into login(username, password, account_type) values('%s','%s', '%s')", l.getUsername(), l.getPassword(), l.getAccountType());
		
		jdbcTemplate.execute(sql);
		
		sql = "select max(lid) from login";
		
		List<Integer> list = jdbcTemplate.query(sql, new RowMapper<Integer>() {

			@Override
			public Integer mapRow(ResultSet rs, int rowId) throws SQLException {
				return new Integer(rs.getInt(1));
			}
		});
		return list.get(0);
	}
	
	public boolean validateUser(String username, String password) {
		System.out.println(username);
		System.out.println(password);
		String sql = String.format("select * from login where username = '%s' and password = '%s'", username, password);
		System.out.println(sql);
		List<Login> list = jdbcTemplate.query(sql, new RowMapper<Login>() {

			@Override
			public Login mapRow(ResultSet rs, int rowId) throws SQLException {
				Login l = new Login();
				l.setLid(rs.getInt(1));
				l.setUsername(rs.getString(2));
				l.setPassword(rs.getString(3));
				l.setAccountType(rs.getString(4));
				return l;
			}
			
		});
		
		
		if(list.size() == 1) {
			return true;
		} else {
			return false;
		}
	}

}
